package com.wanted.pre_onboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PreOnboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(PreOnboardApplication.class, args);
	}

}
